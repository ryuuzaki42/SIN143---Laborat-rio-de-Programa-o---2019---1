package testeOlaMundoFrame;

import java.awt.Container;
import javax.swing.*;

public class OlaMundoFrame extends JFrame{
    public OlaMundoFrame(){
        createFrame();
    }

    private void createFrame(){
        this.setTitle("Meu primeiro Frame");
        this.setLocation(350,250);
        this.setSize(300,200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container container = getContentPane();
        container.add(new OlaMundoPanel());
    }
}
