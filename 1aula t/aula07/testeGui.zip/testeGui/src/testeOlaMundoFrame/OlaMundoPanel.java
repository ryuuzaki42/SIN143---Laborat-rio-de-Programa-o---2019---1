package testeOlaMundoFrame; 

import java.awt.*;
import javax.swing.*;

public class OlaMundoPanel extends JPanel{
    public void paintComponent(Graphics g){
        super.paintComponents(g);

        Font arialB24 = new Font("Arial", Font.BOLD,24);
        g.setFont(arialB24);
        g.setColor(Color.red);
        g.drawString("Olá Mundo", 100, 70);

        g.drawOval(10,10, 80, 30);
        g.drawRect(150,10, 80, 30);
    }
}
