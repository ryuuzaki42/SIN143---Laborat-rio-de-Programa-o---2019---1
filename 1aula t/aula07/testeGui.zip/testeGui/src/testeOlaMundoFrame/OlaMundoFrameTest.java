package testeOlaMundoFrame; 

import java.awt.Color;

public class OlaMundoFrameTest{
    public static void main(String[] args) {
        OlaMundoFrame frame = new OlaMundoFrame();
        frame.setBackground(Color.black);
        frame.setVisible(true);
    }
}
