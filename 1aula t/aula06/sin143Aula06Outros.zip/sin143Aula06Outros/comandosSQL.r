
show databases;

show tables;

create database dbNome;

use dbNome;

drop table tableNome;
drop database dbNome;

create user userNome@localhost identified by 'senha123';

grant all on dbNome.* to 'userNome'@'localhost';

create table tableNome(id int primary key auto_increment, nome varchar(100), qtd int);

insert into tableNome(nome, qtd) values('farinha', 9);

select * from tableNome;

drop user userNome@localhost;

SELECT user, host FROM mysql.user;

./mysql -u root

./mysql -uuserNome -psenha123
