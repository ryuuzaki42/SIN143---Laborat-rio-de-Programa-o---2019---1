-----------------------------------------------------------------------------
stmt.execute("CREATE TABLE Pessoa"
    + " (id INT AUTO_INCREMENT"
    + ", nome varchar(50)"
    + ", endereco varchar(50)"
    + ", telefone varchar(20)"
    + ", cpf varchar(20)"
    + ", PRIMARY KEY(id))");
-----------------------------------------------------------------------------
stmt.executeUpdate("INSERT INTO"
    + " Pessoa (nome, endereco, telefone, cpf)"
    + " VALUES "
    + " ('Marco Antonio', 'CNB 14 LOTE 10', '33521134', '832869')");
-----------------------------------------------------------------------------
String nomeDaPessoa;
int idPessoa;
String enderecoDaPessoa;

ResultSet rs = stmt.executeQuery("SELECT * FROM Pessoa");
while (rs.next()) {
    idPessoa = rs.getInt("id");
    nomeDaPessoa = rs.getString("nome");
    enderecoDaPessoa = rs.getString("endereco");
    // Continua para todas as colunas

    //Depois, faça algo com os valores obtidos, como mostrar numa tela
    System.out.println("ID: " + idPessoa
        + "Nome: " + nomeDaPessoa + "Endereco: " + enderecoDaPessoa);
}
-----------------------------------------------------------------------------
String sql = "INSERT INTO Pessoa (nome, endereco, telefone,"
        + " cpf) values (?, ?, ?, ?)";
PreparedStatement preStmt = con.prepareStatement(sql);
preStmt.setString(1, "Marco Antonio");
preStmt.setString(2, "CNB 14 LOTE 10");
preStmt.setString(3, "33521134");
preStmt.setString(4, "832869");
preStmt.executeUpdate();
-----------------------------------------------------------------------------
CREATE TABLE tabela_01 (
    tab01_indice int(10) unsigned NOT NULL AUTO_INCREMENT,
    tab01_nome varchar(45) NOT NULL,
    PRIMARY KEY (tab01_indice));
-----------------------------------------------------------------------------
