package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class Conexao {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/dbNome";
            Connection con = DriverManager.getConnection(url, "userNome", "senha123");
            System.out.println("con: " + con);

            Statement stmt = con.createStatement();
            String queryInsert = "insert into tableNome(nome, qtd) values('farinha', 9)";
            stmt.executeUpdate(queryInsert);

            String querySelect = "select * from tableNome";
            ResultSet rs = stmt.executeQuery(querySelect);
            while(rs.next()) {
                System.out.println("Id: " + rs.getInt(1) + " Nome: " + rs.getString(2) + " qtd: " + rs.getInt(3));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (ClassNotFoundException | SQLException ex) {
            //Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error: " + ex);
        }
    }
}
