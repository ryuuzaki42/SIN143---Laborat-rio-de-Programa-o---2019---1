package conexao;

//import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Banco {
    // login do Banco
    private String login;
    // senha do Banco private
    private String senha;
    // IP do servidor do Banco
    private String host;
    // Nome do Banco de dados
    private String dbname;
    // URL de conexão do Banco
    private String url;
    // Objeto do tipo Connection para estabeler a conexão
    private Connection conection;
    // Objeto Statement usado para enviar consultas para o Banco de dados
    private Statement stmt;
    // Objeto ResultSet utilizado nas consultas ao Banco de dados
    private ResultSet rst;
    // String utilizada para realizar as consultas ao Banco
    private String query;

    public Banco() {
        login = "user2";
        senha = "123456";
        host = "localhost";
        dbname = "exemploDB";
        url = "jdbc:mysql://" + host + "/" + dbname;
        conection = null;
        stmt = null;
    }

    public boolean setConecta() {
        try {
            // Carrega o driver mysql
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Estabelecendo a conexão
            conection = DriverManager.getConnection(url, login, senha);
            return true;
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error" + e);
            return false;
        }
    }

    public boolean setDesconecta() {
        try {
            conection.close();
            return true;
        } catch(SQLException e) {
            System.out.println("Error:" + e);
            return false;
        }
    }

    public boolean insertExemplo() {
        try {
            // Instanciando o objeto Statement a partir do objeto
            // Connection criado
            stmt = conection.createStatement();
            // Query para inserção
            query = "insert into tabela_01 (tab01_nome) values ('Jose')";
            stmt.executeUpdate(query);
            return true;
        } catch(SQLException e) {
            System.out.println("Error: " + e);
            return false;
        }
    }

    public boolean deleteExemplo() {
        try {
            // Instanciando o objeto Statement a partir do
            // objeto Connection criado
            stmt = conection.createStatement();
            // Query para deleção
            query = "delete from tabela_01 where tab01_indice = 3";
            stmt.executeUpdate(query);
            return true;
        } catch(SQLException e) {
            System.out.println("Error: " + e);
            return false;
        }
    }

    public boolean updateExemplo() {
        try {
            // Instanciando o objeto Statement a partir do
            // objeto Connection criado
            stmt = conection.createStatement();
            // Query para update
            query = "update tabela_01 set tab01_nome='Jonas' where tab01_indice = 2";
            stmt.executeUpdate(query);
            return true;
        } catch(SQLException e) {
            System.out.println("Error: " + e);
            return false;
        }
    }

    public ResultSet selectExemplo() {
        try {
            // Instanciando o objeto Statement a partir do objeto
            // Connection criado
            stmt = conection.createStatement();
            // Query para select do nome 'Jose'
            //query = "select * from tabela_01 where tab01_nome = 'Jose'";
            // Query para select de todos os nomes
            query = "select * from tabela_01";
            rst = stmt.executeQuery(query);
            return rst;
        } catch(SQLException e) {
            System.out.println("Error: " + e);
            return null;
        }
    }
}
